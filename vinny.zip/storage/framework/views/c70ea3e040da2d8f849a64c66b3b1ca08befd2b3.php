<div id="header" class="pt-5">
    <div class="pt-5 top">
        <div class="d-flex pl-5">
            <div class="ml-5">
                <img class="me shadow" src="assets/me.jpg" alt="" >
            </div>
           
            <div class="position-relative w-100">
                <div class="ml-5">
                <p class="name title mb-0">Vincent Mogaka</p>
                <span class="d-block sub-title">Fullstack Web Developer (Freelancer)</span>

                <div class="mt-4 txt-light txt-big">
                    <div>NAIROBI, KENYA</div>
                    <div>WEB HOSTING SERVICE PROVIDER</div>
                    
                </div>
                </div>
                

                <div class="nav ">
                    <li class="col"><a href=""> <i class="fas fa-server pr-2"></i> WEB HOSTING</a></li>
                    <li class="col"><a href=""> <i class="fab fa-laravel pr-2"></i> WEB DESIGN</a></li>
                    <li class="col"><a href=""> <i class="fas fa-file-download pr-2"></i> MY RESUME</a></li>
                    <li class="col"><a href=""> <i class="fas fa-headphones-alt pr-2"></i> CONTACT ME</a></li>
                </div>
               
            </div>
        </div>
       
    </div>
</div><?php /**PATH C:\Projects\Vinny\resources\views/client/inc/header.blade.php ENDPATH**/ ?>