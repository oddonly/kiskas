@extends('layouts.main')
@section('content')
<div style="margin-top:-150px;">
   <div class="about">
       <div class="container pl-5">
            <div class="title title-sm">Selamat, jawaban anda untuk pertanyaan 1 sudah BENAR.<br><br>
            Silakan buka amplop "BONUS A" dan kunjungi halaman di bawah ini untuk menjawab pertanyaan 2.</div>
            <br><br>
            <a href="/D040593-2">MENUJU PERTANYAAN 2</a>
       </div>
       
   </div>

</div>
@endsection

@section('footer')
    <div id="footer">
        <div class="container p-0">
            &copy; 2022 - Net Detective Indonesia
        </div>
    </div>
@endsection
