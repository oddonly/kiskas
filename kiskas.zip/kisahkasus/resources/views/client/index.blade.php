@extends('layouts.main')
@section('content')
<div style="margin-top:-150px;">
   <div class="about">
       <div class="container pl-5">
            <div class="title title-sm">NO. KASUS: D-040593</div>
            <div class="col-md-6 p-0 pt-3">
                <a href="/D040593-1"><img src="/assets/D040593.png" /></a><br/>
                <p>"Ada Dusta Di Antara Kita"</p>
            </div>
       </div>
       
   </div>

</div>
@endsection

@section('footer')
    <div id="footer">
        <div class="container p-0">
            &copy; 2022 - Net Detective Indonesia
        </div>
    </div>
@endsection
