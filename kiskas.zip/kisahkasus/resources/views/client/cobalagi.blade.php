@extends('layouts.main')
@section('content')
<div style="margin-top:-150px;">
   <div class="about">
       <div class="container pl-5">
            <div class="title title-sm">Maaf jawaban belum tepat, silakan coba lagi.</div>
            <br><br>
            <div class="col-md-6">
                <button onclick="history.back()">Kembali</button>
            </div>
       </div>
       
   </div>

</div>
@endsection

@section('footer')
    <div id="footer">
        <div class="container p-0">
            &copy; 2022 - Net Detective Indonesia
        </div>
    </div>
@endsection
