<div id="header" class="pt-5" style="background-image: url('assets/bg.jpg');background-size: cover;">

    <div class="pt-5 top">
        <div class="d-flex pl-5">
           
            <div class="position-relative w-100">
                <div class="ml-5">
                <p class="name title mb-0">Kisah Kasus</p>
                <span class="d-block sub-title">Net Detective Indonesia</span>
                
                </div>
               
            </div>
        </div>
       
    </div>
</div><?php /**PATH /var/www/kisahkasus/resources/views/client/inc/header.blade.php ENDPATH**/ ?>