
<?php $__env->startSection('content'); ?>
<div style="margin-top:-150px;">
   <div class="about">
       <div class="container pl-5">
            <div class="title title-sm">Selamat, anda telah memecahkan kasus ini!<br><br>
            Untuk membuka semua misteri dan menutup kasus, silakan buka amplop "BONUS C".</div>
            <br><br>
       </div>
       
   </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <div id="footer">
        <div class="container p-0">
            &copy; 2022 - Net Detective Indonesia
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/kisahkasus/resources/views/client/betulQ3.blade.php ENDPATH**/ ?>